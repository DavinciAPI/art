function ImageGenerator() {
    const [prompt, setPrompt] = React.useState('');
    const [isLoading, setIsLoading] = React.useState(false);
    const [generatedImage, setGeneratedImage] = React.useState(null);
    const [error, setError] = React.useState(null);
    const [retryCount, setRetryCount] = React.useState(0);
    const [recentImages, setRecentImages] = React.useState([]);
    const maxRetries = 10;
    const maxRecentImages = 6;

    React.useEffect(() => {
        try {
            const savedImages = JSON.parse(localStorage.getItem('recentImages')) || [];
            setRecentImages(savedImages);
        } catch (error) {
            reportError(error);
            setRecentImages([]);
        }
    }, []);

    const saveToRecent = (imageUrl) => {
        try {
            const updatedImages = [imageUrl, ...recentImages].slice(0, maxRecentImages);
            setRecentImages(updatedImages);
            localStorage.setItem('recentImages', JSON.stringify(updatedImages));
        } catch (error) {
            reportError(error);
        }
    };

    const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

    const handleDownload = async () => {
        try {
            const response = await fetch(generatedImage);
            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `ghibli-art-${Date.now()}.png`;
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);
        } catch (error) {
            reportError(error);
            setError('Failed to download image. Please try again.');
        }
    };

    const generateImage = async (e) => {
        try {
            e.preventDefault();
            setIsLoading(true);
            setError(null);
            setRetryCount(0);

            let response;
            let isModelLoading = true;
            
            while (isModelLoading && retryCount < maxRetries) {
                response = await fetch('https://api-inference.huggingface.co/models/runwayml/stable-diffusion-v1-5', {
                    method: 'POST',
                    headers: {
                        'Authorization': 'Bearer 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',
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        inputs: `${prompt} in ghibli style, anime style, studio ghibli, highly detailed, digital art`,
                        parameters: {
                            num_inference_steps: 50,
                            guidance_scale: 7.5,
                            width: 512,
                            height: 512
                        }
                    }),
                });

                if (response.status === 503) {
                    const errorData = await response.json();
                    if (errorData.error.includes("loading")) {
                        setRetryCount(prev => prev + 1);
                        const waitTime = Math.min(errorData.estimated_time * 1000 || 20000, 20000);
                        await sleep(waitTime);
                        continue;
                    }
                }

                isModelLoading = false;
            }

            if (retryCount >= maxRetries) {
                throw new Error("Maximum retry attempts reached. Please try again later.");
            }

            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`HTTP error! status: ${response.status}. description: ${errorText}`);
            }

            const blob = await response.blob();
            const imageUrl = URL.createObjectURL(blob);
            setGeneratedImage(imageUrl);
            saveToRecent(imageUrl);
        } catch (error) {
            reportError(error);
            setError(error.message || 'Failed to generate image. Please try again.');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <section className="image-generator" id="generator" data-name="image-generator-section">
            <div className="container">
                <h2 className="generator-title" data-name="generator-title">
                    Ghibli Style Image Generator
                </h2>
                <div className="generator-content" data-name="generator-content">
                    <form onSubmit={generateImage} className="generator-form" data-name="generator-form">
                        <textarea
                            className="prompt-input"
                            value={prompt}
                            onChange={(e) => setPrompt(e.target.value)}
                            placeholder="Enter your prompt (e.g., A magical forest with glowing mushrooms)"
                            required
                            data-name="prompt-input"
                        />
                        <button 
                            type="submit" 
                            className="generate-btn"
                            disabled={isLoading}
                            data-name="generate-button"
                        >
                            {isLoading ? 'Generating...' : 'Generate Image'}
                        </button>
                    </form>
                    
                    {error && (
                        <div className="error-message" data-name="error-message">
                            {error}
                        </div>
                    )}
                    
                    {isLoading && (
                        <div className="loading-container" data-name="loading-container">
                            <div className="loading-spinner"></div>
                            <p>Creating your magical image... This may take up to 30 seconds.</p>
                            {retryCount > 0 && (
                                <p className="retry-message">
                                    Model is warming up. Attempt {retryCount} of {maxRetries}...
                                </p>
                            )}
                        </div>
                    )}
                    
                    {generatedImage && !isLoading && (
                        <div className="image-result" data-name="image-result">
                            <img 
                                src={generatedImage} 
                                alt="Generated Ghibli Style Image"
                                className="generated-image"
                                data-name="generated-image"
                            />
                            <button 
                                onClick={handleDownload}
                                className="download-btn"
                                data-name="download-button"
                            >
                                <svg className="w-5 h-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                                    <path d="M10 12l-5-5 1.41-1.41L10 9.17l3.59-3.58L15 7l-5 5z"/>
                                    <path d="M10 18a8 8 0 100-16 8 8 0 000 16zm0-2a6 6 0 110-12 6 6 0 010 12z"/>
                                </svg>
                                Download Image
                            </button>
                        </div>
                    )}

                    {recentImages.length > 0 && (
                        <div className="recent-images" data-name="recent-images">
                            <h3 className="recent-title" data-name="recent-title">Recently Generated Images</h3>
                            <div className="images-grid" data-name="images-grid">
                                {recentImages.map((url, index) => (
                                    <a 
                                        key={index}
                                        href={url}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="recent-image-container"
                                        data-name={`recent-image-${index}`}
                                    >
                                        <img 
                                            src={url} 
                                            alt={`Recent Generation ${index + 1}`}
                                            className="recent-image"
                                        />
                                    </a>
                                ))}
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </section>
    );
}
