function Hero() {
    try {
        return (
            <section className="hero relative" data-name="hero-section">
                <ParticleEffect />
                <div className="container relative z-10">
                    <div className="flex justify-between items-center">
                        <div className="w-1/2" data-name="hero-content">
                            <div className="text-sm mb-4" data-name="hero-label">ILLUSTRATOR</div>
                            <h1 className="hero-title" data-name="hero-title">CHERIF AHCENE</h1>
                            <p className="hero-subtitle" data-name="hero-description">
                                Creating dynamic and imaginative anime-inspired art that brings stories to life.
                            </p>
                            <button className="learn-more-btn" data-name="learn-more-button">
                                LEARN MORE
                                <svg className="ml-2 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7"/>
                                </svg>
                            </button>
                        </div>
                        <div className="w-1/2 hero-image-container" data-name="hero-image-container">
                            <img 
                                src="https://i.postimg.cc/7PJ8pR3v/Screenshot-10.png" 
                                alt="Cherif Ahcene"
                                className="hero-image" 
                                data-name="hero-image"
                            />
                        </div>
                    </div>
                </div>
            </section>
        );
    } catch (error) {
        reportError(error);
        return null;
    }
}
